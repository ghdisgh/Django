from django.views.generic import ListView, DetailView
from basic.models import recipe


class recipeLV(ListView):
    model = recipe
    template_name = 'basic/recipe_all.html'     
    context_object_name = 'recipes'
    paginate_by = 3

class recipeDV(DetailView): # 상세정보를 출력 기본키인 slug 값을 가져와 상세페이지 출력
    model = recipe

