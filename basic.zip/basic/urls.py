from django.conf.urls import url
from basic.views import *

app_name = 'basic'

urlpatterns = [

    url(r'^recipe/$',recipeLV.as_view(), name = 'recipe_list'), 

    url(r'^recipe/(?P<slug>[-\w]+)/$',recipeDV.as_view(), name = 'recipe_detail'),
    
]
