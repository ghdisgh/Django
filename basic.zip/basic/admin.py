from django.contrib import admin
from basic.models import recipe

class recipeAdmin(admin.ModelAdmin): #post 들어가서 admin첫화면에 보여지는 부분
    list_display = ('title', 'modify_date') #보이는 화면
    list_filter = ('modify_date',) # 오른쪽에 보이는 필터
    search_fields = ('title', 'content')# 검색창
    prepopulated_fields = {'slug': ('title',)} 

admin.site.register(recipe, recipeAdmin)