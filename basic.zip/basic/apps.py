from django.apps import AppConfig


class BasicConfig(AppConfig):
    name = 'basic'
