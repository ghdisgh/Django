from django.conf.urls import include, url
from django.contrib import admin
from django.urls import path

from django.conf.urls.static import static
from django.conf import settings

from modori.views import HomeView,thxView
from modori.views import UserCreateView, UserCreateDoneTV

urlpatterns = [
    path('admin/', admin.site.urls),

    url(r'^accounts/', include('django.contrib.auth.urls')), # 사용자에 관련된 url 장고에서 이미정의 ex) 로그인,비밀번호
    url(r'^accounts/register/$', UserCreateView.as_view(), name='register'), # 회원가입
    url(r'^accounts/register/done/$', UserCreateDoneTV.as_view(), name = 'register_done'), # 회원가입 완료


    url(r'^$', HomeView.as_view(), name='home'),
    url(r'^thx/', thxView.as_view(), name='thx'),
    url(r'^blog/', include('blog.urls', namespace='blog')),
    url(r'^review/', include('review.urls', namespace='review')),
    url(r'^basic/', include('basic.urls', namespace='basic')),
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
