from django.db.models.fields.files import ImageField, ImageFieldFile
from PIL import Image, ImageOps
import os

def _add_thumb(s):
    parts = s.split(".") # . 으로 구분하여 쪼갬
    parts.insert(-1, "thumb") 
    if parts[-1].lower() not in ['jpeg', 'jpg']: # jpeg or  jpg 가 아니면 jpg로 바꿔라
        parts[-1] = 'jpg'
    return ".".join(parts)
    

class ThumbnailImageFieldFile(ImageFieldFile):
    def _get_thumb_path(self):
        return _add_thumb(self.path)
    thumb_path = property(_get_thumb_path)
    
    def _get_thumb_url(self):
        return _add_thumb(self.url)
    thumb_url = property(_get_thumb_url)

    def save(self, name, content, save=True):
        super(ThumbnailImageFieldFile, self).save(name, content, save)
        img = Image.open(self.path)

        size = (128, 128) # 같은 사이즈로 변경
        img.thumbnail(size, Image.ANTIALIAS)
        background = Image.new('RGBA', size, (255, 255, 255, 0)) # 배경색을 지정
        background = background.convert('RGB') # Pillow 높은 버전 부터 jpeg 지원안해서 바꿔줘야함
        background.paste(
            img, ( int((size[0] - img.size[0]) / 2), int((size[1] - img.size[1]) / 2) ) )
        background.save(self.thumb_path, 'JPEG')

    def delete(self, save=True):
        if os.path.exists(self.thumb_path):
            os.remove(self.thumb_path)
        super(ThumbnailImageFieldFile, self).delete(save)


class ThumbnailImageField(ImageField):
    attr_class = ThumbnailImageFieldFile

    def __init__(self, thumb_width=128, thumb_height=128, *args, **kwargs):
        self.thumb_width = thumb_width
        self.thumb_height = thumb_height
        super(ThumbnailImageField, self).__init__(*args, **kwargs)