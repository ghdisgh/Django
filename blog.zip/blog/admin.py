from django.contrib import admin
from blog.models import recipe, Bookmark

# Register your models here.
class BookInline(admin.StackedInline): # 앨범안쪽에 넣을 포토
    model = Bookmark

class recipeAdmin(admin.ModelAdmin): #post 들어가서 admin첫화면에 보여지는 부분
    inlines = [BookInline]
    list_display = ('title', 'modify_date') #보이는 화면
    list_filter = ('modify_date',) # 오른쪽에 보이는 필터
    search_fields = ('title', 'content')# 검색창
    prepopulated_fields = {'slug': ('title',)}
   
class BookmarkAdmin(admin.ModelAdmin):
    list_display = ('title', 'url') #리스트 형태로 보여줭

admin.site.register(Bookmark, BookmarkAdmin)
admin.site.register(recipe, recipeAdmin)