from django.conf.urls import url
from blog.views import *

app_name = 'blog'

urlpatterns = [

    url(r'^bookmark/$', BookmarkLV.as_view(), name='book'),

    url(r'^recipe/$',recipeLV.as_view(), name = 'recipe_list'), 

    url(r'^recipe/(?P<slug>[-\w]+)/$',recipeDV.as_view(), name = 'recipe_detail'),

    url(r'^tag/(?P<tag>[^/]+(?u))/$', PostTOL.as_view(), name='tagged_object_list'), 
    
]
