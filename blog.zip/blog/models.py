from django.db import models
from django.urls import reverse

from blog.fields import ThumbnailImageField
from tagging.fields import TagField

# Create your models here.

class recipe(models.Model): # admin에서 post 추가할때 보여질 테이블
    title = models.CharField('TITLE', max_length=50)
    slug = models.SlugField('SLUG', unique=True, allow_unicode=True, help_text = 'one word for title alias.') #기본키지정
    description = models.CharField('DESCRIPTION', max_length=100, blank=True, help_text = 'simple description text.')
    image = ThumbnailImageField(upload_to='photo/%Y/%m')
    content = models.TextField('CONTENT')
    create_date = models.DateTimeField('Create Date', auto_now_add=True)
    modify_date = models.DateTimeField('Modify Date', auto_now=True)
    tag = TagField()

    class Meta:
        verbose_name = 'recipe' #단수이름
        verbose_name_plural = 'recipes' # 복수이름
        db_table = 'my_recipe' # 테이블의 이름 디폴트는 blog_post
        ordering = ('-modify_date',) # 정렬

    def __str__(self): 
        return self.title

    def get_absolute_url(self):
        return reverse('blog:recipe_detail', args=(self.slug,))

    def get_previous_post(self):
        return self.get_previous_by_modify_date() #이전 내장함수

    def get_next_post(self):
        return self.get_next_by_modify_date()


class Bookmark(models.Model):
    recipe = models.ForeignKey(recipe,on_delete=models.CASCADE)
    title = models.CharField(max_length=100, blank = True, null=True)
    url = models.URLField('url', unique=True)

    class Meta:
        verbose_name = 'book' #단수이름
        verbose_name_plural = 'books' # 복수이름

    def __str__(self): 
        return self.title




    

   