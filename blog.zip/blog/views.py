from django.views.generic import ListView, DetailView
from blog.models import recipe, Bookmark
from tagging.models import Tag, TaggedItem
from tagging.views import TaggedObjectList


class BookmarkLV(ListView) :
    model = Bookmark
    template_name = 'blog/bookmark_list.html'

class recipeLV(ListView):
    model = recipe
    template_name = 'blog/recipe_all.html'     
    context_object_name = 'recipes'
    paginate_by = 3

class PostTOL(TaggedObjectList):
     model = recipe # post에 관련된 리스트를 가져오는 클래스
     template_name = 'tagging/tagging_post_list.html'

class recipeDV(DetailView): # 상세정보를 출력 기본키인 slug 값을 가져와 상세페이지 출력
    model = recipe
