from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible

from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse

from review.fields import ThumbnailImageField



# Create your models here.

@python_2_unicode_compatible
class Album(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField('One Line Description', max_length=100, blank=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    
    class Meta:
        ordering = ['name'] # 정렬을 이름으로 하겟다
        
    def __str__(self):
        return self.name
        
    def get_absolute_url(self):
        return reverse('review:album_detail', args=(self.id,))

@python_2_unicode_compatible
class Photo(models.Model):
    album = models.ForeignKey(Album,on_delete=models.CASCADE) # 앨범 외래키 사용 채과 버전이 다르므로 삭제 되었을때 연관된것 다 삭제된다는것을 넣어줘야함
    title = models.CharField(max_length=50)
    image = ThumbnailImageField(upload_to='photo/%Y/%m') # 사진저장 경로
    description = models.TextField('Photo Description', blank=True)
    upload_date = models.DateTimeField('Upload Date', auto_now_add=True)
        
    class Meta:
        ordering = ['title'] # 정렬을 사진이름으로 함
        
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('review:photo_detail', args=(self.id,)) # id 값을 가지고 절대경로 지정

