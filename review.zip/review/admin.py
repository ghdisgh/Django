from django.contrib import admin
from review.models import Album, Photo

# Register your models here.
class PhotoInline(admin.StackedInline): # 앨범안쪽에 넣을 포토
    model = Photo
    extra = 2 # 앨범에 2개씩 추가할수있게 만듯것

class AlbumAdmin(admin.ModelAdmin):
    inlines = [PhotoInline] # 위에서 정의한 것
    list_display = ('name', 'description')

class PhotoAdmin(admin.ModelAdmin):
    list_display = ('title', 'upload_date')

admin.site.register(Album, AlbumAdmin)    
admin.site.register(Photo, PhotoAdmin)
